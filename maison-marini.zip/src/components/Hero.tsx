/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { IMAGES } from "../constants";

export default function Hero() {
  return (
    <section className="relative h-screen w-full overflow-hidden bg-luxury-black">
      {/* Background Image Container */}
      <motion.div
        initial={{ scale: 1.1, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 2.5, ease: [0.19, 1, 0.22, 1] }}
        className="absolute inset-0 z-0"
      >
        <img
          src={IMAGES.HERO}
          alt="Maison Marini Hero"
          className="w-full h-full object-cover brightness-75 contrast-125"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-luxury-black via-transparent to-transparent" />
      </motion.div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-end pb-24 px-6">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 2.5, duration: 1.5, ease: "easeOut" }}
          className="text-center"
        >
          <span className="text-[10px] uppercase tracking-[0.5em] opacity-60 mb-6 block">
            Autumn Winter 2026
          </span>
          <h1 className="text-5xl md:text-8xl lg:text-9xl font-serif mb-8 tracking-tighter leading-none">
            Futuro <span className="italic">Classico</span>
          </h1>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-12">
            <button className="group relative px-8 py-3 overflow-hidden">
              <span className="relative z-10 text-[10px] uppercase tracking-[0.4em] text-white">
                Discover Collection
              </span>
              <motion.div 
                className="absolute inset-x-0 bottom-0 h-[100%] bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" 
                layoutId="hero-btn"
              />
              <div className="absolute bottom-0 left-0 w-full h-[1px] bg-white/20 group-hover:bg-white transition-colors" />
            </button>
            <button className="text-[10px] uppercase tracking-[0.4em] opacity-40 hover:opacity-100 transition-opacity">
              Watch Film
            </button>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ delay: 4, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center"
      >
        <div className="w-[1px] h-12 bg-gradient-to-b from-white to-transparent" />
      </motion.div>
    </section>
  );
}
