/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { Menu, Search, ShoppingBag } from "lucide-react";

export default function Navbar() {
  return (
    <motion.nav
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 2.2, duration: 1, ease: "easeOut" }}
      className="fixed top-0 left-0 w-full z-40 px-6 md:px-12 py-8 flex items-center justify-between pointer-events-none"
    >
      <div className="flex items-center space-x-8 pointer-events-auto">
        <button className="text-luxury-white/60 hover:text-luxury-white transition-colors">
          <Menu size={20} strokeWidth={1} />
        </button>
        <button className="hidden md:block text-[10px] uppercase tracking-[0.3em] text-luxury-white/60 hover:text-luxury-white transition-colors">
          Collections
        </button>
        <button className="hidden md:block text-[10px] uppercase tracking-[0.3em] text-luxury-white/60 hover:text-luxury-white transition-colors">
          Maison
        </button>
      </div>

      <div className="absolute left-1/2 -translate-x-1/2 pointer-events-auto">
        <h2 className="text-xl md:text-2xl font-serif tracking-[0.3em] uppercase">
          Maison Marini
        </h2>
      </div>

      <div className="flex items-center space-x-8 pointer-events-auto">
        <button className="hidden md:block text-[10px] uppercase tracking-[0.3em] text-luxury-white/60 hover:text-luxury-white transition-colors">
          Search
        </button>
        <button className="text-luxury-white/60 hover:text-luxury-white transition-colors">
          <ShoppingBag size={20} strokeWidth={1} />
        </button>
      </div>
    </motion.nav>
  );
}
