/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";

export default function Footer() {
  return (
    <footer className="pt-32 pb-12 px-6 md:px-12 bg-luxury-black border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-24">
          <div className="md:col-span-1">
            <h3 className="text-xl font-serif tracking-widest uppercase mb-8">
              Maison Marini
            </h3>
            <p className="text-[10px] uppercase tracking-widest leading-loose text-white/40">
              Via del Proconsolo, 50122 <br />
              Firenze FI, Italia
            </p>
          </div>
          
          <div>
            <span className="text-[10px] uppercase tracking-[0.4em] opacity-40 block mb-6">Explore</span>
            <ul className="space-y-4">
              {["High Fashion", "Ready-to-Wear", "Accessories", "Campaigns"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[10px] uppercase tracking-[0.3em] hover:text-white transition-colors duration-300 opacity-60 hover:opacity-100">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <span className="text-[10px] uppercase tracking-[0.4em] opacity-40 block mb-6">Concierge</span>
            <ul className="space-y-4">
              {["Client Advisor", "Shipping", "Returns", "Contact"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[10px] uppercase tracking-[0.3em] hover:text-white transition-colors duration-300 opacity-60 hover:opacity-100">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <span className="text-[10px] uppercase tracking-[0.4em] opacity-40 block mb-6">Newsletter</span>
            <div className="relative border-b border-white/20 pb-2">
              <input 
                type="email" 
                placeholder="YOUR EMAIL" 
                className="bg-transparent border-none text-[10px] uppercase tracking-[0.4em] w-full focus:outline-none placeholder:opacity-20"
              />
              <button className="absolute right-0 top-0 text-[10px] uppercase tracking-[0.4em]">Sign Up</button>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-white/5">
          <p className="text-[8px] uppercase tracking-[0.5em] opacity-20 mb-4 md:mb-0">
            © 2026 Maison Marini. All Rights Reserved.
          </p>
          <div className="flex space-x-8">
            {["Instagram", "WeChat", "X"].map((social) => (
              <a key={social} href="#" className="text-[9px] uppercase tracking-[0.4em] opacity-40 hover:opacity-100 transition-opacity">
                {social}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
