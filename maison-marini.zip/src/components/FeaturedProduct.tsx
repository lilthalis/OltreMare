/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { IMAGES } from "../constants";
import { ArrowRight } from "lucide-react";

export default function FeaturedProduct() {
  return (
    <section className="py-32 px-6 md:px-12 bg-luxury-black">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16 lg:gap-32">
        {/* Product Visualization */}
        <div className="w-full lg:w-1/2 relative">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="aspect-square relative overflow-hidden glass rounded-sm"
          >
            <img
              src={IMAGES.PRODUCT}
              alt="Maison Marini Highlight"
              className="w-full h-full object-cover p-12 md:p-24"
              referrerPolicy="no-referrer"
            />
            {/* Dramatic radial light effect */}
            <div className="absolute inset-0 bg-radial-gradient from-white/10 to-transparent pointer-events-none" />
          </motion.div>
          
          {/* Decorative Text */}
          <div className="absolute -bottom-10 -right-10 hidden md:block">
            <span className="text-[120px] font-serif italic text-white/5 pointer-events-none select-none">
              Artifact
            </span>
          </div>
        </div>

        {/* Product Details */}
        <div className="w-full lg:w-1/2">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            <span className="text-[10px] uppercase tracking-[0.6em] text-white/40 mb-4 block">
              Highlight No. 01
            </span>
            <h2 className="text-4xl md:text-6xl font-serif tracking-tight mb-8">
              The <span className="italic">Graphite</span> <br /> Structure Bag
            </h2>
            
            <p className="text-sm md:text-base text-luxury-titanium max-w-md mb-12 leading-relaxed font-light">
              Crafted from a single block of titanium-treated leather. Zero seams. Infinite precision. Designed to be more than an accessory—a sculptural piece of Italian engineering.
            </p>

            <div className="flex flex-col space-y-6">
              <div className="flex items-center space-x-12 pb-6 border-b border-white/10 w-fit">
                <span className="text-[10px] uppercase tracking-[0.4em] opacity-40">Price</span>
                <span className="text-lg font-serif">€ 4,200</span>
              </div>
              
              <button className="flex items-center space-x-4 group">
                <span className="text-[10px] uppercase tracking-[0.5em] group-hover:tracking-[0.7em] transition-all duration-500">
                  Acquire Artifact
                </span>
                <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform duration-500" strokeWidth={1} />
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
