/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { IMAGES } from "../constants";

const collections = [
  {
    title: "The Silent Silhouette",
    category: "Menswear",
    image: IMAGES.COLLECTION_1,
    size: "large",
  },
  {
    title: "Eternal Architecture",
    category: "Womenswear",
    image: IMAGES.COLLECTION_2,
    size: "medium",
  },
];

export default function Collections() {
  return (
    <section className="py-32 px-6 md:px-12 bg-luxury-black">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="mb-24 text-center md:text-left"
        >
          <h2 className="text-3xl md:text-5xl font-serif tracking-tight mb-4">
            Curated <span className="italic">Excellence</span>
          </h2>
          <p className="max-w-md text-xs uppercase tracking-[0.3em] text-luxury-titanium leading-relaxed">
            Exploration of form, shadow, and materiality in modern Italian tailoring.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-24 items-start">
          {/* Card 1 - Left Column (Large) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="md:col-span-7 group cursor-pointer"
          >
            <div className="relative overflow-hidden aspect-[3/4] mb-8">
              <motion.img
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
                src={collections[0].image}
                alt={collections[0].title}
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-luxury-black/10 group-hover:bg-transparent transition-colors duration-700" />
            </div>
            <div className="flex justify-between items-end">
              <div>
                <span className="text-[10px] uppercase tracking-[0.4em] text-luxury-titanium mb-2 block">
                  {collections[0].category}
                </span>
                <h3 className="text-xl md:text-2xl font-serif tracking-wide group-hover:tracking-widest transition-all duration-700">
                  {collections[0].title}
                </h3>
              </div>
              <button className="text-[10px] uppercase tracking-[0.3em] pb-1 border-b border-white/20 hover:border-white transition-colors">
                View Series
              </button>
            </div>
          </motion.div>

          {/* Card 2 - Right Column (Medium, Offset Down) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, delay: 0.2, ease: "easeOut" }}
            className="md:col-span-5 md:mt-48 group cursor-pointer"
          >
            <div className="relative overflow-hidden aspect-[4/5] mb-8">
              <motion.img
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
                src={collections[1].image}
                alt={collections[1].title}
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-luxury-black/10 group-hover:bg-transparent transition-colors duration-700" />
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-[0.4em] text-luxury-titanium mb-2 block">
                {collections[1].category}
              </span>
              <h3 className="text-xl md:text-2xl font-serif tracking-wide group-hover:tracking-widest transition-all duration-700">
                {collections[1].title}
              </h3>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
