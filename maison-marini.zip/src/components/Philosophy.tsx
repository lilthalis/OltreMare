/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";

export default function Philosophy() {
  return (
    <section className="py-48 px-6 md:px-12 bg-white text-luxury-black overflow-hidden relative">
      {/* Background Architectural Grid (Subtle) */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <div className="grid grid-cols-12 h-full w-full">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="border-r border-luxury-black h-full" />
          ))}
        </div>
      </div>

      <div className="max-w-4xl mx-auto relative z-10 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="mb-12"
        >
          <span className="text-[10px] uppercase tracking-[0.6em] text-luxury-black/40 block mb-8">
            L'Origine
          </span>
          <h2 className="text-4xl md:text-6xl font-serif leading-tight tracking-tight">
            Design is NOT a choice. <br />
            <span className="italic">It is a destiny.</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.5, delay: 0.3 }}
          className="flex flex-col space-y-8"
        >
          <p className="text-lg md:text-xl font-serif italic text-luxury-black/80 max-w-2xl leading-relaxed">
            Maison Marini was born from the intersection of Italian artisan heritage and the technological void of the future. We don't create fashion; we construct armor for the soul.
          </p>
          
          <div className="w-[1px] h-24 bg-luxury-black/20 mx-auto" />
          
          <p className="text-[10px] uppercase tracking-[0.4em] text-luxury-black/60 max-w-md mx-auto leading-loose">
            Founded in Florence. Reimagined for the global digital age. Minimalist. Emotional. Eternal.
          </p>
        </motion.div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          className="mt-16 text-[10px] uppercase tracking-[0.5em] px-12 py-4 border border-luxury-black/10 hover:border-luxury-black transition-all"
        >
          Read the Manifesto
        </motion.button>
      </div>
    </section>
  );
}
