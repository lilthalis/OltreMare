/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { REGIONS } from "../constants";

interface GatewayProps {
  onEnter: (region: string) => void;
}

export default function Gateway({ onEnter }: GatewayProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.5, ease: "easeInOut" }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-luxury-black text-luxury-white h-screen w-full"
    >
      <div className="relative flex flex-col items-center max-w-sm w-full px-6">
        {/* Cinematic Logo */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 1, ease: "easeOut" }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-serif tracking-widest uppercase">
            Maison Marini
          </h1>
        </motion.div>

        {/* Elegant Phrase */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ delay: 1, duration: 1.5 }}
          className="text-sm md:text-base font-serif italic mb-16 tracking-widest text-center"
        >
          Una maison italiana oltre il tempo.
        </motion.p>

        {/* Region Selector */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="flex flex-col items-center space-y-6 w-full"
        >
          <span className="text-[10px] uppercase tracking-[0.3em] opacity-40 mb-2">Select Region</span>
          <div className="flex flex-col space-y-4 w-full">
            {REGIONS.map((region) => (
              <button
                key={region}
                onClick={() => onEnter(region)}
                className="group relative py-2 overflow-hidden"
              >
                <span className="relative z-10 text-xs uppercase tracking-[0.4em] transition-all duration-500 group-hover:tracking-[0.6em] opacity-60 group-hover:opacity-100">
                  {region}
                </span>
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-[1px] bg-white/40 transition-all duration-700 group-hover:w-1/2" />
              </button>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Decorative vertical line */}
      <motion.div
        initial={{ scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ delay: 0.2, duration: 2, ease: "circInOut" }}
        className="absolute bottom-0 left-1/2 w-[1px] h-24 bg-gradient-to-t from-white/20 to-transparent origin-bottom"
      />
    </motion.div>
  );
}
