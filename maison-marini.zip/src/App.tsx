/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "motion/react";
import Gateway from "./components/Gateway";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Collections from "./components/Collections";
import Philosophy from "./components/Philosophy";
import FeaturedProduct from "./components/FeaturedProduct";
import Footer from "./components/Footer";

export default function App() {
  const [isEntered, setIsEntered] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState("");

  const handleEnter = (region: string) => {
    setSelectedRegion(region);
    setIsEntered(true);
    // Smooth scroll to top when entering
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    if (isEntered) {
      document.body.style.overflow = "auto";
    } else {
      document.body.style.overflow = "hidden";
    }
  }, [isEntered]);

  return (
    <div className="relative font-sans">
      <AnimatePresence mode="wait">
        {!isEntered ? (
          <Gateway onEnter={handleEnter} />
        ) : (
          <motion.main
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="selection:bg-luxury-silver selection:text-luxury-black"
          >
            <Navbar />
            <Hero />
            <Collections />
            <Philosophy />
            <FeaturedProduct />
            <Footer />
          </motion.main>
        )}
      </AnimatePresence>

      {/* Cinematic Transition Overlay */}
      <AnimatePresence>
        {isEntered && (
          <motion.div
            initial={{ scaleY: 1 }}
            animate={{ scaleY: 0 }}
            transition={{ duration: 1.2, ease: [0.19, 1, 0.22, 1], delay: 0.2 }}
            className="fixed inset-0 z-[60] bg-luxury-white origin-top pointer-events-none"
          />
        )}
      </AnimatePresence>
    </div>
  );
}
