export const IMAGES = {
  HERO: "/src/assets/images/hero_maison_marini_1779103553133.png",
  COLLECTION_1: "/src/assets/images/collection_editorial_1_1779103569097.png",
  COLLECTION_2: "/src/assets/images/collection_editorial_2_1779103586928.png",
  PRODUCT: "/src/assets/images/product_art_object_1779103601574.png",
};

export const REGIONS = ["Italia", "Brasile", "International"];
